from django.contrib import admin
from crm.models import Ishchi, User
from crm.models.auth import Chat
# Register your models here.

admin.site.register(Ishchi)
admin.site.register(User)
admin.site.register(Chat)