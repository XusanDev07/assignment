from django.db import models


# Create your models here.

class Ishchi(models.Model):
    ism = models.CharField(max_length=128)
    familiya = models.CharField(max_length=128)
    yosh = models.IntegerField()
    lavozm = models.CharField(max_length=128)
    maosh = models.CharField(max_length=128)

    def __str__(self):
        return self.ism
