from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from methodism import error_params_unfilled
from crm.models import User
from crm.models.auth import Chat


# Create your views here.

@login_required(login_url="login")
def index(request):
    a = Chat.objects.all()

    return render(request, 'index.html', {"all": a})


def sign_in(request):
    if not request.user.is_anonymous:
        return redirect("home")

    if request.POST:
        data = request.POST
        user = User.objects.filter(email=data['email']).first()
        print(data)
        if not user:
            return render(request, 'auth/login.html', {"error": "Wrong user or password"})

        if not user.check_password(data['pass']):
            return render(request, 'auth/login.html', {"error": "Wrong password"})

        if not user.is_active:
            return render(request, 'auth/login.html', {"error": "Profil active emas "})

        login(request, user)
        return redirect('home')

    return render(request, 'auth/login.html')


def sign_up(request):
    if request.POST:
        data = request.POST
        if not data:
            return render(request, 'auth/register.html', {"error": error_params_unfilled(data)})
        fname = data['fname']
        lname = data['lname']
        email = data['email']
        password = data['password']
        chek_p = data['chek_password']

        user = User.objects.filter(email=data['email']).first()
        if user:
            return render(request, 'auth/register.html', {"error": "Bunday uzer mavjud"})

        if password != chek_p:
            return render(request, 'auth/register.html', {"error": "Parol teng email"})

        User.objects.create_user(email, password, lname=lname, fname=fname)

        authenticate(request)
        login(request, user)
        return redirect('home')

    return render(request, 'auth/register.html')


def user_format(request, pk=None, status=None):
    if pk:
        user = User.objects.filter(id=pk).first()
        if user and status in [1, 0]:
            a = True if status == 1 else False
            user.perm = a
            user.save()
            return redirect('user_format')
    users = User.objects.all()
    return render(request, 'auth/list_user.html', {"all": users})


def opt(request):
    if request.POST:
        return redirect('home')
    return render(request, 'otp/otp.html')
