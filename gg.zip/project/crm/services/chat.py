from django.shortcuts import redirect, render
from crm.models.auth import Chat


def chat(request):
    if request.POST:
        data = request.POST
        user = request.user
        if not user:
            return render(request, './chat.html', {"error": "Bunaqa user yoq"})
        msg = data['text']

        Chat.objects.get_or_create(user=user, text=msg)

        return render(request, './chat.html')

    a = Chat.objects.all()
    return render(request, './chat.html', {"all": a})
