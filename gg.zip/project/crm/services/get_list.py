from django.contrib.auth.decorators import login_required

from crm.models import Ishchi
from django.shortcuts import render


@login_required(login_url="login")
def get_ishchi(requests):
    ctx = {
        "all": Ishchi.objects.all()
    }
    return render(requests, "ishchi/list.html", ctx)
