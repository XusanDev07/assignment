from django.urls import path
from crm.services.auth import index, sign_in, sign_up, user_format, opt as otp
from crm.services.get_list import get_ishchi
from crm.services.chat import chat

urlpatterns = [
    path('', index, name='home'),

    path('ishchi', get_ishchi, name='ishchi_list'),
    path('otp/', otp, name='otp'),
    path("login/", sign_in, name='login'),
    path("regis/", sign_up, name='regis'),
    path("user_format/", user_format, name='user_format'),
    path("user_format/<int:pk>/<int:status>/", user_format, name='user_format_2'),
    path("chat", chat, name='chat'),
]